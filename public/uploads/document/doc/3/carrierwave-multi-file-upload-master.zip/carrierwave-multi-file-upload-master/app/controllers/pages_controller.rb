class PagesController < ApplicationController

end
