# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CarrierwaveMultiFileUpload::Application.config.secret_token = 'f0aad957ef05c82e0e8f69559897eadda15ebcc52557069e5262c6ce0a4fcb72f48e4765b7264d22c89e8a04f9c92f79914aad249fd310b73702ca8588670b0c'
