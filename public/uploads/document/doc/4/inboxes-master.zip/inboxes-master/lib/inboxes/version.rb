module Inboxes
  VERSION = "0.2.2"
end
